<?
include ("../config.inc.php");
include ("top_foot.inc.php");

$q=($_GET['q']!="")? $_GET['q'] :"";
$tipo=($_GET['tipo']!="")? $_GET['tipo'] :"";

$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
  die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
  or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

switch ($tipo)
  {
  case "divisione":
  $query = "SELECT DISTINCT divisione FROM gendivordclafam WHERE divisione like '$q%' ORDER By divisione";
  $result = mysql_query($query, $db);
  while ($row = mysql_fetch_array($result))
    { 
    echo "$row[divisione]|$row[divisione]\n";
    }
  break;
  case "classe":
  $query = "SELECT DISTINCT classe FROM gendivordclafam WHERE classe like '$q%' ORDER By classe";
  $result = mysql_query($query, $db);
  while ($row = mysql_fetch_array($result))
    { 
    echo "$row[classe]|$row[classe]\n";
    }
  break;
  case "ordine":
  $query = "SELECT DISTINCT ordine FROM gendivordclafam WHERE ordine like '$q%' ORDER By ordine";
  $result = mysql_query($query, $db);
  while ($row = mysql_fetch_array($result))
    { 
    echo "$row[ordine]|$row[ordine]\n";
    }
  break; 
  case "famiglia":
  $query = "SELECT DISTINCT famiglia FROM gendivordclafam WHERE famiglia like '$q%' ORDER By famiglia";
  $result = mysql_query($query, $db);
  while ($row = mysql_fetch_array($result))
    { 
    echo "$row[famiglia]|$row[famiglia]\n";
    }
  break;
  case "genere":
  $query = "SELECT DISTINCT genere FROM genspecie WHERE genere like '$q%' ORDER By genere";
  $result = mysql_query($query, $db);
  while ($row = mysql_fetch_array($result))
    { 
    echo "$row[genere]|$row[genere]\n";
    }
  break;  
  }

?>