<?
$id=$_REQUEST['id'];
$genere=$_REQUEST['genere'];
$specie=$_REQUEST['specie'];
$genspe=$_REQUEST['genspe'];

include("top_foot.inc.php");
include("../config.inc.php");
top_admin();
link_admin();

  $db = mysql_connect($db_host, $db_user, $db_password);
  if ($db == FALSE)
    die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  mysql_select_db($db_name, $db)
    or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");


$query = "DELETE FROM archivio WHERE id='$id'";

if (mysql_query($query, $db))
	   	$stampa='Cancellazione tabella Archivio avvenuta con successo. Riga' . $id;
else
		$stampa='Errore cancellazione dati - Tabella Archivio!!!';


if ($genspe=1){
	$querygenspe = "DELETE FROM genspecie WHERE genere='$genere' AND specie='$specie'";

		if (mysql_query($querygenspe, $db))
	   	$stampa2='Cancellazione tabella Genere-Specie avvenuta con successo';
		else
		$stampa2='Errore cancellazione dati - Tabella Genere-Specie!!!';
}
else
$stampa2='Tabella Genere-Specie non cancellata';

?>

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

				  <td valign="top" bgcolor="#e6e6fa" width="954" height="327">

					  <div align="center">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

 												<tbody>

 													<tr class="testo1" height="50">

 														<td bgcolor="#e6e6fa" width="894" height="50">

 															<div align="center">

 																<b><?
 																echo "$stampa";
 																?></b><br>
 																<b><?
 																echo "$stampa2";
 																?></b><br>
 															</div>														</td>
 													</tr>
 												</tbody>
											</table>
                                            <p>&nbsp;</p>
                  </table>


<?
	//endif;
	  mysql_close($db);
// chiude la verifica della presenza dei dati
foot();
?>
