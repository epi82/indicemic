<?
$genere=$_REQUEST['genere'];
$specie=$_REQUEST['specie'];
$divisione=$_REQUEST['divisione'];
$ordine=$_REQUEST['ordine'];
$classe=$_REQUEST['classe'];
$famiglia=$_REQUEST['famiglia'];
$tossi=$_REQUEST['tossi'];
$post=$_REQUEST['post'];
$carica=$_REQUEST['carica'];

include("top_foot.inc.php");
include("../config.inc.php");
include("../functions.php");
top_admin();
link_admin();

switch ($carica){
case 'genspecie':
	$tabella="genspecie";
	$campo1="genere";
	$campo2="specie";
	$presente=verifica_genspe($tabella,$campo1,$campo2,$genere,$specie);
	
	if (trim($genere) == "" OR trim($specie) == ""){$stampa2="I campi Genere, Specie devono essere riempiti!";}
	elseif ($presente == '1') $stampa2="Genere-Specie presenti in archivio";
  	else {
  	$genere = addslashes(stripslashes($genere));
  	$specie = addslashes(stripslashes($specie));
  	$genere = str_replace("<", "&lt;", $genere);
  	$genere = str_replace(">", "&gt;", $genere);
  	$specie = str_replace("<", "&lt;", $specie);
  	$specie = str_replace(">", "&gt;", $specie);
  	$db = mysql_connect($db_host, $db_user, $db_password);
  	if ($db == FALSE)
    	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  	mysql_select_db($db_name, $db)
    	or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

	$query = "INSERT INTO genspecie (genere, specie) VALUES ('$genere', '$specie')";
    	if (mysql_query($query, $db))
	   	$stampa='Genere-Specie inseriti correttamente';
    	else
		$stampa='Errore inserimento dati!!!';
	mysql_close($db);
		}
break;
case 'divordclafam':
  $tabella="gendivordclafam";
  $campo="genere";
  $valore=$genere;
  $presente=verifica($tabella,$campo,$valore);
  
  if (trim($genere) == "" OR trim($divisione) == "" OR trim($classe) == "" OR trim($ordine) == "" OR trim($famiglia) == "")
    $stampa2="I campi Divisione,Ordine,Classe,Famiglia devono essere riempiti!";
  elseif ($presente == '1') $stampa2="Genere presente in archivio per la tabella [Divisione-Ordine-Classe-Famiglia]";
  else {
    $genere = addslashes(stripslashes($genere));
    $divisione = addslashes(stripslashes($divisione));
    $ordine = addslashes(stripslashes($ordine));
    $classe = addslashes(stripslashes($classe));
    $famiglia = addslashes(stripslashes($famiglia));
    $genere = str_replace("<", "&lt;", $genere);
    $genere = str_replace(">", "&gt;", $genere);
    $divisione = str_replace("<", "&lt;", $divisione);
    $divisione = str_replace(">", "&gt;", $divisione);
    $ordine = str_replace("<", "&lt;", $ordine);
    $ordine = str_replace(">", "&gt;", $ordine);
    $classe = str_replace("<", "&lt;", $classe);
    $classe = str_replace(">", "&gt;", $classe);
    $famiglia = str_replace("<", "&lt;", $famiglia);
    $famiglia = str_replace(">", "&gt;", $famiglia);
    
    $db = mysql_connect($db_host, $db_user, $db_password);
  
    if ($db == FALSE)
      die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

    mysql_select_db($db_name, $db)
      or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

    $query = "INSERT INTO gendivordclafam (genere, divisione, ordine, classe, famiglia) VALUES ('$genere', '$divisione', '$ordine', '$classe', '$famiglia')";
      if (mysql_query($query, $db))
      $stampa='Divisione-Ordine-Classe-Famiglia inseriti correttamente per [Genere] = ' . $genere;
      else
    $stampa='Errore inserimento dati!!!';
  mysql_close($db);
    }
break;
/*
case 'div':
	$tabella="divisione";
	$campo="divisione";
	$valore=$div;
	$presente=verifica($tabella,$campo,$valore);
	if (trim($div) == ""){echo "Il campo Divisione deve essere riempito!";}
	elseif ($presente == '1') echo "Divisione gi� presente in archivio";
  	else {
 	 $div = addslashes(stripslashes($div));
 	 $div = str_replace("<", "&lt;", $div);
 	 $div = str_replace(">", "&gt;", $div);
 	 $db = mysql_connect($db_host, $db_user, $db_password);
  	if ($db == FALSE)
    	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  	mysql_select_db($db_name, $db)
    	or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

	$query = "INSERT INTO divisione (divisione) VALUES ('$div')";
    	if (mysql_query($query, $db))
	   	$stampa='Divisione inserita correttamente';
    	else
		$stampa='Errore inserimento dati!!!';
	mysql_close($db);
		}
break;
case 'classe':
	$tabella="classe";
	$campo="classe";
	$valore=$classe;
	$presente=verifica($tabella,$campo,$valore);
	
	if (trim($classe) == ""){echo "Il campo Classe deve essere riempito!";}
  	elseif ($presente == '1') echo "Classe gi� presente in archivio";
	else {
 	 $classe = addslashes(stripslashes($classe));
 	 $classe = str_replace("<", "&lt;", $classe);
 	 $classe = str_replace(">", "&gt;", $classe);
 	 $db = mysql_connect($db_host, $db_user, $db_password);
  	if ($db == FALSE)
    	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  	mysql_select_db($db_name, $db)
    	or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

	$query = "INSERT INTO classe (classe) VALUES ('$classe')";
    	if (mysql_query($query, $db))
	   	$stampa='Classe inserita correttamente';
    	else
		$stampa='Errore inserimento dati!!!';
	mysql_close($db);
		}
break;
case 'ordine':

	$tabella="ordine";
	$campo="ordine";
	$valore=$ordine;
	$presente=verifica($tabella,$campo,$valore);
		
	if (trim($ordine) == ""){echo "Il campo Ordine deve essere riempito!";}
  	elseif ($presente == '1') echo "Ordine gi� presente in archivio";
	else
	 {
 	 $ordine = addslashes(stripslashes($ordine));
 	 $ordine = str_replace("<", "&lt;", $ordine);
 	 $ordine = str_replace(">", "&gt;", $ordine);
 	 $db = mysql_connect($db_host, $db_user, $db_password);
  	if ($db == FALSE)
    	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  	mysql_select_db($db_name, $db)
    	or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

	$query = "INSERT INTO ordine (ordine) VALUES ('$ordine')";
    	if (mysql_query($query, $db))
	   	$stampa='Ordine inserito correttamente';
    	else
		$stampa='Errore inserimento dati!!!';
	mysql_close($db);
		}
break;
case 'fami':

	$tabella="famiglia";
	$campo="famiglia";
	$valore=$fami;
	$presente=verifica($tabella,$campo,$valore);
		
	if (trim($fami) == ""){echo "Il campo Famiglia deve essere riempito!";}
  	elseif ($presente == '1') echo "Famiglia gi� presente in archivio";
	else
	 {
 	 $ordine = addslashes(stripslashes($fami));
 	 $ordine = str_replace("<", "&lt;", $fami);
 	 $ordine = str_replace(">", "&gt;", $fami);
 	 $db = mysql_connect($db_host, $db_user, $db_password);
  	if ($db == FALSE)
    	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  	mysql_select_db($db_name, $db)
    	or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

	$query = "INSERT INTO famiglia (famiglia) VALUES ('$fami')";
    	if (mysql_query($query, $db))
	   	$stampa='Famiglia inserita correttamente';
    	else
		$stampa='Errore inserimento dati!!!';
	mysql_close($db);
		}
break;
 
 */
case 'tossi':
	$tabella="tossicologia";
	$campo="tossi";
	$valore=$tossi;
	
	$presente=verifica($tabella,$campo,$valore);
	if (trim($tossi) == "" OR trim($post) == ""){$stampa2="I campi Tossicologia, Post devono essere riempiti!";}
	elseif ($presente == '1') $stampa2="Tossicologia gi� presente in archivio";
  	else {
  	$tossi = addslashes(stripslashes($tossi));
  	$post = addslashes(stripslashes($post));
  	$tossi = str_replace("<", "&lt;", $tossi);
  	$tossi = str_replace(">", "&gt;", $tossi);
  	$post = str_replace("<", "&lt;", $post);
  	$post = str_replace(">", "&gt;", $post);
  	$db = mysql_connect($db_host, $db_user, $db_password);
  	if ($db == FALSE)
    	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  	mysql_select_db($db_name, $db)
    	or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

	$query = "INSERT INTO tossicologia (tossi, post) VALUES ('$tossi', '$post')";
    	if (mysql_query($query, $db))
	   	$stampa='Link Tossicologia inserito correttamente';
    	else
		$stampa='Errore inserimento dati!!!';
	mysql_close($db);
		}
break;
}

?>
<
<table class="Table_Corpo" width="980" cellpadding="10" height="351">
    <tr class="testo1" height="327">
	     <td valign="top" bgcolor="#e6e6fa" width="954" height="327">
			     <div align="center">
					         <table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
 									    <tbody>
 											    <tr class="testo1" height="50">
 													    <td bgcolor="#e6e6fa" width="894" height="50">
 															    <div align="center">
 																     <b><? echo $stampa; ?></b>
 																     <br />
 															    </div>
 															</td>
 													</tr>
 													<tr class="testo1" height="50">
                              <td bgcolor="#e6e6fa" width="894" height="50">
                                  <div align="center">
                                     <b><? echo $stampa2; ?></b>
                                     <br />
                                  </div>
                              </td>
                          </tr>
 										  </tbody>
									</table>
           </div>
       </td>
    </tr>                   
</table>

<?
// chiude la verifica della presenza dei dati

foot();
?>
