<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

top_admin();
?>

<table class="Table_Corpo" cellpadding="10" height="351" width="980">
	<tbody><tr class="testo1" height="327">
	  <td height="327" valign="top" width="954">
		<div align="center">
		  <p>&nbsp;</p>

        <table border="0" cellpadding="4" cellspacing="1">
            <tbody>
                <tr></tr></tbody></table>
                <table align="center" cellspacing="1" width="500" border="1">
                  <tbody><tr>
                    <th scope="row" bgcolor="#FFFFFF" width="100"><img src="images/indice_schede.gif" height="50" width="50"></th>
                    <td class="testo1" bgcolor="#FFFFFF" width="250"><div align="left">&nbsp;&nbsp;Scheda</div></td>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./insert.php"><img src="images/aggiungi.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./edit.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./delete.php"><img src="images/cancella.gif" border="0"></a></th>
                  </tr>
                  <tr>
                    <th scope="row" bgcolor="#FFFFFF" width="100"><img src="images/albero.gif" height="34" width="50"></th>
                    <td class="testo1" bgcolor="#FFFFFF" width="250"><div align="left">&nbsp;&nbsp;Genere-specie</div></td>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./carica.php?carica=genspecie"><img src="images/aggiungi.gif" border="0"></a></th>
					          <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./edit_genspe.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><img src="images/cancella.gif"></th>
                  </tr>
                  <tr>
                    <th scope="row" bgcolor="#FFFFFF" width="100"><img src="images/albero.gif" height="34" width="50"></th>
                    <td class="testo1" bgcolor="#FFFFFF" width="250"><div align="left">&nbsp;&nbsp;Divisione-Classe-Ordine-Famiglia</div></td>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./carica.php?carica=divordclafam"><img src="images/aggiungi.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./edit_gendivordclafam.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><img src="images/cancella.gif"></th>
                  </tr>    
       <!--              
                  <tr>
                    <th scope="row" bgcolor="#e5fdf7" width="100"><img src="images/albero.gif" height="34" width="50"></th>
                    <td class="testo1" bgcolor="#e5fdf7" width="250"><div align="left">&nbsp;&nbsp;Divisione</div></td>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><a href="./carica.php?carica=div"><img src="images/aggiungi.gif" border="0"></a></th>
					<th scope="row" bgcolor="#e5fdf7" width="50"><a href="./edit_div.php"><img src="images/edita.gif" border="0"></th>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><img src="images/cancella.gif"></th>
                  </tr>
				  <tr>
                    <th scope="row" bgcolor="#e5fdf7" width="100"><img src="images/albero.gif" height="34" width="50"></th>
                    <td class="testo1" bgcolor="#e5fdf7" width="250"><div align="left">&nbsp;&nbsp;Classe</div></td>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><a href="./carica.php?carica=classe"><img src="images/aggiungi.gif" border="0"></a></th>
					<th scope="row" bgcolor="#e5fdf7" width="50"><a href="./edit_classe.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><img src="images/cancella.gif"></th>
                  </tr>
				  <tr>
                    <th scope="row" bgcolor="#e5fdf7" width="100"><img src="images/albero.gif" height="34" width="50"></th>
                    <td class="testo1" bgcolor="#e5fdf7" width="250"><div align="left">&nbsp;&nbsp;Ordine</div></td>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><a href="./carica.php?carica=ordine"><img src="images/aggiungi.gif" border="0"></a></th>
					<th scope="row" bgcolor="#e5fdf7" width="50"><a href="./edit_ordine.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><img src="images/cancella.gif"></th>
                  </tr>
				  <tr>
                    <th scope="row" bgcolor="#e5fdf7" width="100"><img src="images/albero.gif" height="34" width="50"></th>
                    <td class="testo1" bgcolor="#e5fdf7" width="250"><div align="left">&nbsp;&nbsp;Famiglia</div></td>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><a href="./carica.php?carica=fami"><img src="images/aggiungi.gif" border="0"></a></th>
					<th scope="row" bgcolor="#e5fdf7" width="50"><a href="./edit_famiglia.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#e5fdf7" width="50"><img src="images/cancella.gif"></th>
                  </tr>
				  <tr>
				   --> 
                    <th scope="row" bgcolor="#FFFFFF" width="100"><img src="images/indice_tossico.gif" height="36" width="36"></th>
                    <td class="testo1" bgcolor="#FFFFFF" width="250"><div align="left">&nbsp;&nbsp;Link Tossicologia</div></td>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./carica.php?carica=tossi"><img src="images/aggiungi.gif" border="0"></a></th>
					          <th scope="row" bgcolor="#FFFFFF" width="50"><a href="./edit_tossi.php"><img src="images/edita.gif" border="0"></a></th>
                    <th scope="row" bgcolor="#FFFFFF" width="50"><img src="images/cancella.gif"></th>
                  </tr>
                </tbody></table>
                <p>&nbsp;</p></div></td>
              </tr>
        </tbody></table>

<table class="Table_Coda" height="30" width="980">
	<tbody><tr>
		<td>
		<div align="center">
			<table border="0" cellpadding="0" cellspacing="2" width="940">
				<tbody><tr>
					<td width="940">
					<div class="testo0" align="left"><font color="#FFFFFF">Elia Curti - WebMaster A.M.I.N.T. </font>
					</div>
					</td>
				</tr>
			</tbody></table>
		</div>
		</td>
	</tr>
</tbody></table>

  
<p></p>
</center></body></html>