<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
top_admin();
link_admin();

$tossi=($_GET['tossi']!="")? $_GET['tossi'] :"";
$post=($_GET['post']!="")? $_GET['post'] :"";
$edita=($_GET['edita']!="")? $_GET['edita'] :"";
$verifica=($_GET['verifica']!="")? $_GET['verifica'] :"";
$id=($_GET['id']!="")? $_GET['id'] :"";
$tossi_old=($_GET['tossi_old']!="")? $_GET['tossi_old'] :"";

$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");


$query = "SELECT tossi, post FROM tossicologia ORDER BY tossi";
$result = mysql_query($query, $db);

if ($tossi!=""){
$querydiv = "SELECT id, tossi, post FROM tossicologia WHERE tossi LIKE '{$tossi}'";
$resultdiv = mysql_query($querydiv, $db);
}

?>

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">


					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Modifica Tossicologia</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table>										</td>
									</tr>
								</tbody>
							</table>

					          <p>&nbsp;</p>
<form method="get" action="edit_tossi.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td>
</td>
</tr>
<tr class="testo1">
<td align="center" width="800">
Tossicologia:&nbsp;&nbsp;<select name="tossi">
<?
if ($edita=="")
{
	while ($row = mysql_fetch_array($result))
	{
?>
		<option value="<? echo "$row[tossi]"?>"><? echo "$row[tossi]"?></option>
<?
		
	}
}
else if ($edita=="si"){
?>
	<option value="<? echo "$tossi"?>"><? echo "$tossi"?></option>
<?
	}
?>
</select>
</td>
</table>
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
<input type="image" src="../images/delete.png">
</td>
<td width="400" align="right">
<input onclick="form.edita.value='si'" type="image" src="images/blocca.png">
<input name="edita" type="hidden"/>
</td>
</tr>
</table>
</form>

<?
switch ($edita)
{

	case "si":
	while ($row = mysql_fetch_array($resultdiv))
		{
?>
<form method="get" action="edit_tossi.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr><td></td></tr>
<tr class="testo1">
<td align="center">
Tossicologia:&nbsp;&nbsp;<input type="text" size="40" name="tossi" value="<? echo "$row[tossi]"?>"/>
post:&nbsp;&nbsp;<input type="text" size="40" name="post" value="<? echo "$row[post]"?>"/>
</td>
</tr>
<tr><td></td></tr>
</table>
<input name="tossi_old" type="hidden" value="<? echo "$row[tossi]" ?>" />
<input name="edita" type="hidden" value="si" />
<input name="id" type="hidden" value="<? echo "$row[id]"; ?>" />
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
</td>
<td width="400" align="right">
<input type="image" src="images/blocca.png">
</td>
</tr>
</table>
</form>
<br /><br />
<?
		}
?>
<? if ($verifica=="")
		{ ?>
<form method="get" action="edit_tossi.php">
<table class="Table_Check" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#427cae" width="30" height="26"><div align="left">Id</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="left">Tossicologia</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="left">Post</div></td>
</tr>
<tr height="26">
<td bgcolor="#dadde4" width="30"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
</tr>
</table>
<br /><br />
<table class="Table_Verifica" border="0" cellspacing="1" cellpadding="4" height="46">
<tr class="testo1">
<td width="400" align="center">Dati non verificati</td>
<td width="400" align="right"><input name="verifica" type="submit" value="Verifica Dati" /></td>
</tr>
</table>
<input name="tossi" type="hidden" value="<? echo "$tossi"; ?>" />
<input name="post" type="hidden" value="<? echo "$post"; ?>" />
<input name="edita" type="hidden" value="<? echo "$edita"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
<input name="tossi_old" type="hidden" value="<? echo "$tossi_old"; ?>" />
</form>
<? 		}
else 
	{ ?>
<form method="post" action="aggiorna_tossi.php">
<table class="Table_Check" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#427cae" width="30" height="26"><div align="left">Id</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="left">Tossicologia</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="left">Post</div></td>
</tr>
<tr height="26">
<td class="testo0" bgcolor="#dadde4" width="30"><div align="left"><? echo "$id" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$tossi" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$post" ?></div></td>
</tr>
</table>
<br /><br />
<table class="Testo0" width="910" border="1" cellpadding="4" height="23">
<tr>
<td align="left">&nbsp;&nbsp;<input type="checkbox" value="1" name="archivio" />&nbsp;&nbsp;Aggiorna anche la tabella ARCHIVIO</td>
</tr>
</table>
<br /><br />
<table class="Table_Verificati" border="0" cellspacing="1" cellpadding="4" height="46">
<tr class="testo1">
<td width="400" align="center">Dati verificati</td>
<td width="400" align="right"><input name="submit" type="submit" value="Aggiorna Dati" /></td>
</tr>
</table>
<input name="tossi" type="hidden" value="<? echo "$tossi"; ?>" />
<input name="post" type="hidden" value="<? echo "$post"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
<input name="tossi_old" type="hidden" value="<? echo "$tossi_old"; ?>" />
</form>
<? } 
break;
}
?>

<br /><br />

                                </p>
					          <p>&nbsp;</p>
					  </div></td>
</table>

<?
// chiusura pagina
foot();
?>