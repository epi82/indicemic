<? function top() { ?>
<html>
	<head>

		<meta name="GENERATOR" content="HTML">

		<meta http-equiv="content-type" content="text/html;charset=iso-8859-1">

		<meta name="DC.Title" content="Amint, associazione, micologica, italiana, naturalistica, telematica">

		<meta name="Description" content="Indice">

		<meta name="Keyword" content="Micologia, Funghi, Sistematica, Tassonomia, Regno Funghi, Indice Funghi, Archivio Funghi, Fungi, Mushroom, Basidiomycota, Ascomycota, Chytrodimycota, Zygomycota, Myxomycota, Licheni">

		<meta name="author" content="Elia Curti">

		<title>Indice Schede Funghi Archivio Generale AMINT</title>

		<link href="stileamint.css" type="text/css" rel="stylesheet">

		<script type="text/javascript" language="JavaScript1.2"></script>

	</head>
	<body background="images/fondo_mic.jpg" topmargin="0">

		<center>

			<table width="64" border="0" cellspacing="2" cellpadding="0">

				<tr height="9">

					<td width="60" height="9"></td>

				</tr>

			</table>
<table Class="Table_Testata" width="980" bgcolor="#00008b" height="55">

				<tr>

					<td bgcolor="#00008b">

						<div align="center">

							<img src="images/testata_micologia.jpg" alt="" height="68" width="974" border="0"></div>

					</td>

				</tr>

			</table>
			
<table Class="Table_coda" width="980" bgcolor="#D3D3D3" height="20">

				<tr>

					<td bgcolor="#B0C4DE">

						<div align="center">

							<table  width="960" border="0" cellspacing="2" cellpadding="0" height="17">

								<tr height="13">

									<td bgcolor="#B0C4DE" width="322" height="13">

										<div align="center">

											<a class="link10" href="http://www.funghiitaliani.it/">Il Meraviglioso Mondo dei Funghi e dei Fiori Spontanei</a></div>

									</td>

									<td bgcolor="#B0C4DE" width="76" height="13">

										<div align="center">

											<a class="link10" href="http://www.funghiitaliani.it/micologia/indice.html">Micologia</a></div>

									</td>

									<td bgcolor="#B0C4DE" width="70" height="13">

										<div align="center">

											<a class="link10" href="http://www.funghiitaliani.it/botanica/indice.html">Botanica</a></div>

									</td>

									<td bgcolor="#B0C4DE" width="92" height="13">

										<div align="center">

											<a class="link10" href="http://shop.amint.it/">Shop AMINT</a></div>

									</td>

									<td bgcolor="#B0C4DE" width="109" height="13">

										<div align="center">

											<a class="link10" href="http://www.funghiitaliani.it/Lezioni%20in%20chat/chat%20funghi.htm">Chat AMINT</a></div>

									</td>

									<td bgcolor="#B0C4DE" width="277" height="13">

										<div align="center"></div>

									</td>

								</tr>

							</table>

						</div>

					</td>

				</tr>

			</table>

</body>
  <? }

function foot() { ?>
  </font>
</p>
</body>
</html>
<? } ?>