<?
$genere=$_REQUEST['genere'];
$divisione=$_REQUEST['divisione'];
$classe=$_REQUEST['classe'];
$ordine=$_REQUEST['ordine'];
$famiglia=$_REQUEST['famiglia'];
$archivio=$_REQUEST['archivio'];

include("top_foot.inc.php");
include("../config.inc.php");

top_admin();
link_admin();

if ($divisione=="" OR $classe=="" OR $ordine=="" OR $famiglia=="")
  $check=0;
else
  $check=1;

  $db = mysql_connect($db_host, $db_user, $db_password);
  if ($db == FALSE)
    die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  mysql_select_db($db_name, $db)
    or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");
	

$query = "UPDATE gendivordclafam SET divisione='$divisione', ordine='$ordine', classe='$classe', famiglia='$famiglia' WHERE genere='$genere'";

$query_archivio = "UPDATE archivio SET divisione='$divisione', ordine='$ordine', classe='$classe', famiglia='$famiglia' WHERE (genere='$genere' AND scheda!='S')";


if ($check==1)  
  {
   
      if (mysql_query($query, $db))
            $stampa1='Modifica tabella Divisione-Ordine-Classe-Famiglia avvenuta con successo. [Genere] = ' . $genere;
      else
            $stampa1='Errore aggiornamento dati!!!';    
      
      switch ($archivio){        
        case "1":
        if (mysql_query($query_archivio, $db))
            $stampa2='Modifica tabella Archivio avvenuta con successo. [Genere] = ' . $genere;
        else
          $stampa2='Errore aggiornamento tabella Archivio!!!';
        
        break;
      } 
       
  }

else
  {
    $stampa1='Aggiornamento non completato. Divisione-Ordine-Classe-Famiglia non possono essere NULL';
    $stampa2=' ';
  }
?>
			
<table class="Table_Corpo" width="980" cellpadding="10" height="351">
    <tr class="testo1" height="327">
	     <td valign="top" bgcolor="#e6e6fa" width="954" height="327">
		      <div align="center">
					       <table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
 								     <tbody>
 										     <tr class="testo1" height="50">
 												     <td bgcolor="#e6e6fa" width="894" height="50">
 														     <div align="center">
 																   <b><? echo "$stampa1";?></b><br>
																   <b><? echo "$stampa2";?></b><br>
 															   </div>
 														 </td>
 												 </tr>
 										 </tbody>
								 </table>
          </div>
       </td>         
    </tr>     
</table>

<?
	//endif;
	  mysql_close($db);
// chiude la verifica della presenza dei dati
foot();
?>
