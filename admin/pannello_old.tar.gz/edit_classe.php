<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
top();

$classe=($_GET['classe']!="")? $_GET['classe'] :"";
$edita=($_GET['edita']!="")? $_GET['edita'] :"";
$verifica=($_GET['verifica']!="")? $_GET['verifica'] :"";
$id=($_GET['id']!="")? $_GET['id'] :"";
$classe_old=($_GET['classe_old']!="")? $_GET['classe_old'] :"";

$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");


$query = "SELECT classe FROM classe ORDER BY classe";
$result = mysql_query($query, $db);

if ($classe!=""){
$querydiv = "SELECT id, classe FROM classe WHERE classe LIKE '{$classe}'";
$resultdiv = mysql_query($querydiv, $db);
}

?>
<table Class="Table_coda" width="980" bgcolor="#D3D3D3" height="20">

				<tr>

					<td bgcolor="#B0C4DE">

							<table  border="0" cellspacing="2" cellpadding="0" height="30">

								<tr>

									<td  align="center" bgcolor="#B0C4DE" width="200" height="30">

											<a class="link10" href="index.php">PANNELLO AMMINISTRAZIONE</a></div>

									</td>

									<td align="center" bgcolor="#B0C4DE" width="200" height="30">


									</td>

								</tr>

							</table>

					</td>

				</tr>

			</table>

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">


					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Modifica Classe</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table>										</td>
									</tr>
								</tbody>
							</table>

					          <p>&nbsp;</p>
<form method="get" action="edit_classe.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td>
</td>
</tr>
<tr class="testo1">
<td align="center" width="350">
Classe:&nbsp;&nbsp;<select name="classe">
<?
if ($edita=="")
{
	while ($row = mysql_fetch_array($result))
	{
?>
		<option value="<? echo "$row[classe]"?>"><? echo "$row[classe]"?></option>
<?
		
	}
}
else if ($edita=="si"){
?>
	<option value="<? echo "$classe"?>"><? echo "$classe"?></option>
<?
	}
?>
</select>
</td>
</table>
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
<input type="image" src="images/cestino.jpg">
</td>
<td width="400" align="right">
<input onclick="form.edita.value='si'" type="image" src="images/blocca.jpg">
<input name="edita" type="hidden"/>
</td>
</tr>
</table>
</form>

<?
switch ($edita)
{

	case "si":
	while ($row = mysql_fetch_array($resultdiv))
		{
?>
<form method="get" action="edit_classe.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr><td></td></tr>
<tr class="testo1">
<td align="center">
Classe:&nbsp;&nbsp;<input type="text" size="40" name="classe" value="<? echo "$row[classe]"?>"/>
</td>
</tr>
<tr><td></td></tr>
</table>
<input name="classe_old" type="hidden" value="<? echo "$row[classe]" ?>" />
<input name="edita" type="hidden" value="si" />
<input name="id" type="hidden" value="<? echo "$row[id]"; ?>" />
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
</td>
<td width="400" align="right">
<input type="image" src="images/blocca.jpg">
</td>
</tr>
</table>
</form>
<br /><br />
<?
		}
?>
<? if ($verifica=="")
		{ ?>
<form method="get" action="edit_classe.php">
<table class="Testo0" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#567DB4" width="30" height="26"><div align="left">Id</div></td>
<td class="testo2" bgcolor="#567DB4" width="130" height="26"><div align="left">Classe</div></td>
</tr>
<tr height="26">
<td bgcolor="#DFE6EF" width="30"><div align="left"></div></td>
<td bgcolor="#DFE6EF" width="130"><div align="left"></div></td>
</tr>
</table>
<br /><br />
<table class="Table_Verifica" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400" align="center">Dati non verificati</td>
<td width="400" align="right"><input name="verifica" type="submit" value="Verifica Dati" /></td>
</tr>
</table>
<input name="classe" type="hidden" value="<? echo "$classe"; ?>" />
<input name="edita" type="hidden" value="<? echo "$edita"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
<input name="classe_old" type="hidden" value="<? echo "$classe_old"; ?>" />
</form>
<? 		}
else 
	{ ?>
<form method="post" action="aggiorna_classe.php">
<table class="Testo0" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#567DB4" width="30" height="26"><div align="left">Id</div></td>
<td class="testo2" bgcolor="#567DB4" width="130" height="26"><div align="left">Classe</div></td>
</tr>
<tr height="26">
<td bgcolor="#DFE6EF" width="30"><div align="left"><? echo "$id" ?></div></td>
<td bgcolor="#DFE6EF" width="130"><div align="left"><? echo "$classe" ?></div></td>
</tr>
</table>
<br /><br />
<table class="Testo0" width="910" border="1" cellpadding="4" height="23">
<tr>
<td align="left">&nbsp;&nbsp;<input type="checkbox" value="1" name="archivio" />&nbsp;&nbsp;Aggiorna anche la tabella ARCHIVIO</td>
</tr>
</table>
<br /><br />
<table class="Table_Verificati" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400" align="center">Dati verificati</td>
<td width="400" align="right"><input name="submit" type="submit" value="Aggiorna Dati" /></td>
</tr>
</table>
<input name="classe" type="hidden" value="<? echo "$classe"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
<input name="classe_old" type="hidden" value="<? echo "$classe_old"; ?>" />
</form>
<? } 
break;
}
?>

<br /><br />

                                </p>
					          <p>&nbsp;</p>
					  </div></td>
</table>

															<table class="Table_Coda" width="980" height="30">

				<tr>

					<td>

						<div align="center">

							<table width="940" border="0" cellspacing="2" cellpadding="0">

								<tr>

									<td width="940"><div class="testo0" align="left"><font color="#00008b">Elia Curti - WebMaster A.M.I.N.T. </font></div></td>

								</tr>

							</table>

						</div>

					</td>

				</tr>

			</table>
<?
// chiusura pagina
foot();
?>