<?
$genere=$_REQUEST['genere'];
$specie=$_REQUEST['specie'];
$autore=$_REQUEST['autore'];
$scheda=$_REQUEST['scheda'];
$comme=$_REQUEST['comme'];
$micro=$_REQUEST['micro'];
$ordine=$_REQUEST['ordine'];
$famiglia=$_REQUEST['famiglia'];
$topic=$_REQUEST['topic'];
$tossi=$_REQUEST['tossi'];
$classe=$_REQUEST['classe'];
$divisione=$_REQUEST['divisione'];
$giorno=$_REQUEST['giorno'];
$mese=$_REQUEST['mese'];
$anno=$_REQUEST['anno'];
$id=$_REQUEST['id'];

include("top_foot.inc.php");
include("../config.inc.php");
top_admin();
link_admin();

if ($scheda=="S")
  {$tipo_scheda=0;}
else
  {$tipo_scheda=1;}

if (trim($genere) == "" OR trim($specie) == "" OR trim($scheda) == "" )
  {
  echo "I campi Genere, Specie, Scheda devono essere riempiti!";
  }
elseif ((trim($divisione) == "" OR trim($classe) == "" OR trim($ordine) == "" OR trim($famiglia) == "") AND $scheda!='S') 
  {
  echo "I campi Divisione-Ordine-Classe-Famiglia devono essere riempiti! Compilare apposita tabella.'";
  }
else 
  {
  $data="$anno$mese$giorno";
  $genere = addslashes(stripslashes($genere));
  $specie = addslashes(stripslashes($specie));
  $genere = str_replace("<", "&lt;", $genere);
  $genere = str_replace(">", "&gt;", $genere);
  $specie = str_replace("<", "&lt;", $specie);
  $specie = str_replace(">", "&gt;", $specie);
  $db = mysql_connect($db_host, $db_user, $db_password);
  if ($db == FALSE)
    die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  mysql_select_db($db_name, $db)
    or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");

  $querytossi = "SELECT post FROM tossicologia WHERE tossi like '$tossi'";
  $resulttossi = mysql_query($querytossi, $db);
  $row = mysql_fetch_array($resulttossi);
  $linktossi = $row[post];
  
  if ($micro == "") {
  $mic=0;
  }
  else {
  $mic=1;
  }

if($tipo_scheda==1)
  {  
     $query = "UPDATE archivio SET genere='$genere', specie='$specie', autore='$autore', scheda='$scheda', micro='$mic', ca='$comme', ordine='$ordine', famiglia='$famiglia', topic='$topic', tossi='$tossi', posttossi='$linktossi', datains='$data', classe='$classe', divisione='$divisione' WHERE id = '$id'";
  }
else
  {
     $query = "UPDATE archivio SET genere='$genere', specie='$specie', autore='$autore', scheda='$scheda', micro=NULL, ca=NULL, ordine=NULL, famiglia=NULL, topic='$topic', tossi=NULL, posttossi=NULL, datains='$data', classe=NULL, divisione=NULL WHERE id = '$id'";
  }
  
  if (mysql_query($query, $db))
	   $stampa='Dati aggiornati correttamente';
  else
	$stampa='Errore inserimento dati!!!';
	}
?>
			
<table class="Table_Corpo" width="980" cellpadding="10" height="351">
				<tr class="testo1" height="327">
				  <td valign="top" bgcolor="#e6e6fa" width="954" height="327">
					  <div align="center">
											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
 												<tbody>
 													<tr class="testo1" height="50">
 														<td bgcolor="#e6e6fa" width="894" height="50">
 															<div align="center">
 																<b><? echo $stampa; ?></b><br>
 															</div>														</td>
 													</tr>
 												</tbody>
											</table>
                  </table>

<?
	//endif;
	  mysql_close($db);
foot();
?>
