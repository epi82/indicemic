<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
top_admin();link_admin();

$genere=($_GET['genere']!="")? $_GET['genere'] :"";
$specie=($_GET['specie']!="")? $_GET['specie'] :"";
$edita=($_GET['edita']!="")? $_GET['edita'] :"";
$verifica=($_GET['verifica']!="")? $_GET['verifica'] :"";
$id=($_GET['id']!="")? $_GET['id'] :"";
$gen_old=($_GET['gen_old']!="")? $_GET['gen_old'] :"";
$spe_old=($_GET['spe_old']!="")? $_GET['spe_old'] :"";

$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");


$query = "SELECT genere, specie FROM genspecie ORDER BY genere";
$result = mysql_query($query, $db);

if ($genere!=""){
$queryspecie = "SELECT genere, specie FROM genspecie WHERE genere LIKE '{$genere}' ORDER BY specie";
$resultspecie = mysql_query($queryspecie, $db);
}

$queryedita = "SELECT id, genere, specie FROM genspecie WHERE genere LIKE '{$genere}' AND specie LIKE '{$specie}'";
$resultedita = mysql_query($queryedita, $db);

?>
<table class="Table_Corpo" width="980" cellpadding="10" height="351">				<tr class="testo1" height="327">					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">					  <div align="center">							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">								<tbody>									<tr>										<td width="940">											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">												<tbody>													<tr class="testo1" height="50">														<td bgcolor="#e6e6fa" width="894" height="50">															<div align="center">																<b>Modifica Genere-specie</b><br>															</div>														</td>													</tr>												</tbody>											</table>										</td>									</tr>								</tbody>							</table>
					          <p>&nbsp;</p>
<form method="get" action="edit_genspe.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td>
</td>
</tr>
<tr class="testo1">
<td align="right" width="350">
Genere:&nbsp;&nbsp;<select name="genere">
<?
if ($genere=="")
{
	while ($row = mysql_fetch_array($result))
	{
		if ($row[genere]!=$inserito)
		{
?>
		<option value="<? echo "$row[genere]"?>"><? echo "$row[genere]"?></option>
<?
		$inserito=$row[genere];
		}
	}
}
else {
?>
	<option value="<? echo "$genere"?>"><? echo "$genere"?></option>
<?
	}
?>
</select>
</td>
<td width="100" align="center">
<input src="../images/ok.png" type="image"></td>
</form>

<form name="genspecie" method="get" action="edit_genspe.php">
<td width="350" align="left">
specie:&nbsp;&nbsp;<select name="specie">
<?
switch ($genere)
{
	case "":
?>
	<option value=""></option>
<?
	break;
	default:
	if ($specie=="")
		{
		while ($row = mysql_fetch_array($resultspecie))
			{
	?>
			<option value="<? echo "$row[specie]"?>"><? echo "$row[specie]"?></option>
	<?
			}
		}
else 
{
?>
<option value="<? echo "$specie"?>"><? echo "$specie"?></option>
<?
}
break;
}
?>
</select>
</td>
</tr>
<tr><td></td></tr>
</table>
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
<input type="image" src="../images/delete.png">
</td>
<td width="400" align="right">
<input onclick="form.genere.value='<? echo "$genere" ?>'" type="image" src="images/blocca.png">
</td>
</tr>
</table>
<input name="genere" type="hidden"/>
<input name="edita" type="hidden" value="si" />
</form>

<?
switch ($edita)
{

	case "si":
	while ($row = mysql_fetch_array($resultedita))
		{
?>
<form method="get" action="edit_genspe.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr><td></td></tr>
<tr class="testo1">
<td align="center">
Genere:&nbsp;&nbsp;<input type="text" size="40" name="genere" value="<? echo "$row[genere]"?>"/>
</td>
<td align="center">
specie:&nbsp;&nbsp;<input type="text" size="40" name="specie" value="<? echo "$row[specie]"?>"/>
</td>
</tr>
<tr><td></td></tr>
</table>
<input name="gen_old" type="hidden" value="<? echo "$row[genere]" ?>" />
<input name="spe_old" type="hidden" value="<? echo "$row[specie]" ?>" />
<input name="edita" type="hidden" value="si" />
<input name="id" type="hidden" value="<? echo "$row[id]"; ?>" />
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
</td>
<td width="400" align="right">
<input type="image" src="images/blocca.png">
</td>
</tr>
</table>
</form>
<br /><br />
<?
		}
?>
<? if ($verifica=="")
		{ ?>
<form method="get" action="edit_genspe.php">
<table class="Testo0" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#567DB4" width="30" height="26"><div align="left">Id</div></td>
<td class="testo2" bgcolor="#567DB4" width="130" height="26"><div align="left">Genere</div></td>
<td class="testo2" bgcolor="#567DB4" width="130" height="26"><div align="left">Specie</div></td>
</tr>
<tr height="26">
<td bgcolor="#DFE6EF" width="30"><div align="left"></div></td>
<td bgcolor="#DFE6EF" width="130"><div align="left"></div></td>
<td bgcolor="#DFE6EF" width="130"><div align="left"></div></td>
</tr>
</table>
<br /><br />
<table class="Table_Verifica" border="0" cellspacing="1" cellpadding="4" height="46">
<tr class="testo1">
<td width="400" align="center">Dati non verificati</td>
<td width="400" align="right"><input name="verifica" type="submit" value="Verifica Dati" /></td>
</tr>
</table>
<input name="genere" type="hidden" value="<? echo "$genere"; ?>" />
<input name="specie" type="hidden" value="<? echo "$specie"; ?>" />
<input name="edita" type="hidden" value="<? echo "$edita"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
<input name="gen_old" type="hidden" value="<? echo "$gen_old"; ?>" />
<input name="spe_old" type="hidden" value="<? echo "$spe_old"; ?>" />
</form>
<? 		}
else 
	{ ?>
<form method="post" action="aggiorna_genspe.php">
<table class="Testo0" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#567DB4" width="30" height="26"><div align="left">Id</div></td>
<td class="testo2" bgcolor="#567DB4" width="130" height="26"><div align="left">Genere</div></td>
<td class="testo2" bgcolor="#567DB4" width="130" height="26"><div align="left">Specie</div></td>
</tr>
<tr height="26">
<td bgcolor="#DFE6EF" width="30"><div align="left"><? echo "$id" ?></div></td>
<td bgcolor="#DFE6EF" width="130"><div align="left"><? echo "$genere" ?></div></td>
<td bgcolor="#DFE6EF" width="130"><div align="left"><? echo "$specie" ?></div></td>
</tr>
</table>
<br /><br />
<table class="Testo0" width="910" border="1" cellpadding="4" height="23">
<tr>
<td align="left">&nbsp;&nbsp;<input type="checkbox" value="1" name="archivio" checked/>&nbsp;&nbsp;Aggiorna anche la tabella ARCHIVIO</td>
</tr><tr><td align="left">&nbsp;&nbsp;<input type="checkbox" value="1" name="divordclafam" checked/>&nbsp;&nbsp;Aggiorna anche la tabella [Divisione-Ordine-Classe-Famiglia]</td></tr>
</table>
<br /><br />
<table class="Table_Verificati" border="0" cellspacing="1" cellpadding="4" height="46">
<tr class="testo1">
<td width="400" align="center">Dati verificati</td>
<td width="400" align="right"><input name="submit" type="submit" value="Aggiorna Dati" /></td>
</tr>
</table>
<input name="genere" type="hidden" value="<? echo "$genere"; ?>" />
<input name="specie" type="hidden" value="<? echo "$specie"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
<input name="gen_old" type="hidden" value="<? echo "$gen_old"; ?>" />
<input name="spe_old" type="hidden" value="<? echo "$spe_old"; ?>" />
</form>
<? } 
break;
}
?>

<br /><br />

                                </p>
					          <p>&nbsp;</p>
					  </div></td>
</table>
<?
// chiusura pagina
foot();
?>