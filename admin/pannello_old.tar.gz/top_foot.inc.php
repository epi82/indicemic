<? function top() { ?>
<html>
  <head>
    <meta name="GENERATOR" content="HTML">
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1">
    <meta name="DC.Title" content="Amint, associazione, micologica, italiana, naturalistica, telematica">
    <meta name="Description" content="Indice">
    <meta name="Keyword" content="Micologia, Funghi, Sistematica, Tassonomia, Regno Funghi, Indice Funghi, Archivio Funghi, Fungi, Mushroom, Basidiomycota, Ascomycota, Chytrodimycota, Zygomycota, Myxomycota, Licheni">
    <meta name="author" content="Elia Curti">
    <title>Indice Schede Funghi Archivio Generale AMINT</title>
    <link href="micologia.css" type="text/css" rel="stylesheet">
    <link rel="shortcut icon" href="http://www.funghiitaliani.it/style_images/immaginiit/favicon.ico" >  
    <script src="javascript/jquery.tools.min.js"></script>  
    <script>
    $(document).ready(function() 
      {
        $(".link20[title]").tooltip();
      });
    </script>
  </head>
  <body topmargin="0" bgcolor="eef3f7">

    <center>

      <table width="64" border="0" cellspacing="2" cellpadding="0">

        <tr height="9">

          <td width="60" height="9"></td>

        </tr>

      </table>
<table Class="Table_Testata" width="980" height="55">

        <tr>

          <td bgcolor="#FFFFFF">

            <div align="center">

              <img src="images/testata_micologia.jpg" alt="" height="68" width="974" border="0"></div>

          </td>

        </tr>

      </table>

<table Class="Table_coda" width="980" bgcolor="#D3D3D3" height="20">

        <tr>

          <td bgcolor="#427cae">

            <div align="center">

              <table  width="960" border="0" cellspacing="2" cellpadding="0" height="17">

                <tr height="13">

                  <td bgcolor="#427cae" width="322" height="13">

                    <div align="center">

                      <a class="link10" href="http://www.funghiitaliani.it/">Il Meraviglioso Mondo dei Funghi e dei Fiori Spontanei</a></div>

                  </td>

                  <td bgcolor="#427cae" width="76" height="13">

                    <div align="center">

                      <a class="link10" href="http://www.funghiitaliani.it/micologia/indice.html">Micologia</a></div>

                  </td>

                  <td bgcolor="#427cae" width="70" height="13">

                    <div align="center">

                      <a class="link10" href="http://www.funghiitaliani.it/botanica/indice.html">Botanica</a></div>

                  </td>

                  <td bgcolor="#427cae" width="92" height="13">

                    <div align="center">

                      <a class="link10" href="http://shop.amint.it/">Shop AMINT</a></div>

                  </td>

                  <td bgcolor="#427cae" width="109" height="13">

                    <div align="center">

                      <a class="link10" href="http://www.funghiitaliani.it/Lezioni%20in%20chat/chat%20funghi.htm">Chat AMINT</a></div>

                  </td>

                  <td bgcolor="#427cae" width="277" height="13">

                    <div align="center"></div>

                  </td>

                </tr>

              </table>

            </div>

          </td>

        </tr>

      </table>

</body>
  <? }

function foot() { ?>
<table class="Table_Coda" width="980" height="30">
        <tr>
          <td>
            <div align="center">
              <table width="940" border="0" cellspacing="2" cellpadding="0">
                <tr>
                  <td width="940"><div class="testo0" align="left"><font color="#FFFFFF">Elia Curti - WebMaster A.M.I.N.T. </font></div></td>
                </tr>
              </table>
            </div>
          </td>
        </tr>
      </table>  
</body>
</html>
<? } 

function foot_index(){ ?>
</body>
</html>
<? }

function top_admin() { ?>
<html>
  <head>
    <meta name="GENERATOR" content="HTML">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="DC.Title" content="Amint, associazione, micologica, italiana, naturalistica, telematica">
    <meta name="Description" content="Indice">
    <meta name="Keyword" content="Micologia, Botanica, Sistematica, Tassonomia, Regno fungi, Basidiomycota, Ascomycota, Chytrodimycota, Zygomycota, Myxomycota, Licheni">
    <meta name="author" content="Elia Curti"><title>Indice lavori micologia sito Amint</title>
    <link href="stileamint.css" type="text/css" rel="stylesheet">
    <link rel="shortcut icon" href="http://www.funghiitaliani.it/style_images/immaginiit/favicon.ico" >
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
    <script src="../javascript/jquery.autocomplete.min.js"></script>
    <script>
    $(document).ready(function() 
      {
        $("#div_id").autocomplete("search.php?tipo=divisione",{minChars: 0});
        $("#cla_id").autocomplete("search.php?tipo=classe",{minChars: 0});
        $("#ord_id").autocomplete("search.php?tipo=ordine",{minChars: 0});
        $("#fam_id").autocomplete("search.php?tipo=famiglia",{minChars: 0});
        $("#gen_id").autocomplete("search.php?tipo=genere",{minChars: 0});
      });
    </script>

  </head>
  <body topmargin="0" bgcolor="2e2e2e">
    <center>
          <table border="0" cellpadding="0" cellspacing="2" width="64">

        <tbody><tr height="9">

          <td height="9" width="60"></td>

        </tr>

      </tbody></table>

<table class="Table_Testata" bgcolor="#00008b" height="55" width="980">
        <tr>
           <td bgcolor="#FFFFFF">
              <div align="center"><img src="images/testata_micologia.jpg" alt="" border="0" width="974" /></div>
           </td>
        </tr>
</table>
    
<table class="Table_coda" height="20" width="980">
    <tbody>
        <tr>
          <td bgcolor="#427cae">
            <div align="center">
              <table border="0" cellpadding="0" cellspacing="2" height="17" width="960">
                <tbody><tr height="13">
                  <td bgcolor="#427cae" height="13" width="322">
                    <div align="center">
                      <a class="link10" href="http://www.funghiitaliani.it/">Il Meraviglioso Mondo dei Funghi e dei Fiori Spontanei</a></div>
                  </td>
                  <td bgcolor="#427cae" height="13" width="76">
                    <div align="center">
                      <a class="link10" href="http://www.funghiitaliani.it/micologia/indice.html">Micologia</a></div>
                  </td>
                  <td bgcolor="#427cae" height="13" width="70">
                    <div align="center">
                      <a class="link10" href="http://www.funghiitaliani.it/botanica/indice.html">Botanica</a></div>
                  </td>
                  <td bgcolor="#427cae" height="13" width="92">
                    <div align="center">
                      <a class="link10" href="http://shop.amint.it/">Shop AMINT</a></div>
                  </td>
                  <td bgcolor="#427cae" height="13" width="109">
                    <div align="center">
                      <a class="link10" href="http://www.funghiitaliani.it/Lezioni%20in%20chat/chat%20funghi.htm">Chat AMINT</a></div>
                  </td>
                  <td bgcolor="#427cae" height="13" width="277">
                    <div align="center"></div>
                  </td>
                </tr>
              </tbody></table>
            </div>
          </td>
        </tr>
      </tbody>
</table>

<?  
  } 
function link_admin(){
?>
<table Class="Table_coda" width="980" height="20">
    <tr>
      <td bgcolor="#427cae">
          <table  border="0" cellspacing="2" cellpadding="0" height="30">
            <tr>
              <td  align="center" bgcolor="#427cae" width="200" height="30">
                  <a class="link10" href="index.php">PANNELLO AMMINISTRAZIONE</a>
              </td>
              <td align="center" bgcolor="#427cae" width="200" height="30">
              </td>
            </tr>
          </table>
      </td>
    </tr>
</table>
<?
}
?>