<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
top_admin();
link_admin();

$genere=($_GET['genere']!="")? $_GET['genere'] :"";
$specie=($_GET['specie']!="")? $_GET['specie'] :"";
$edita=($_GET['edita']!="")? $_GET['edita'] :"";
$verifica=($_GET['verifica']!="")? $_GET['verifica'] :"";
$divisione=($_GET['divisione']!="")? $_GET['divisione'] :"";
$classe=($_GET['classe']!="")? $_GET['classe'] :"";
$ordine=($_GET['ordine']!="")? $_GET['ordine'] :"";
$famiglia=($_GET['famiglia']!="")? $_GET['famiglia'] :"";
$topic=($_GET['topic']!="")? $_GET['topic'] :"";
$tossi=($_GET['tossi']!="")? $_GET['tossi'] :"";
$scheda=($_GET['scheda']!="")? $_GET['scheda'] :"";
$comme=($_GET['comme']!="")? $_GET['comme'] :"";
$micro=($_GET['micro']!="")? $_GET['micro'] :"";
$giorno=($_GET['giorno']!="")? $_GET['giorno'] :"";
$mese=($_GET['mese']!="")? $_GET['mese'] :"";
$anno=($_GET['anno']!="")? $_GET['anno'] :"";
$autore=($_GET['autore']!="")? $_GET['autore'] :"";
$id=($_GET['id']!="")? $_GET['id'] :"";

$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");


$query = "SELECT genere, specie FROM genspecie ORDER BY genere";
$result = mysql_query($query, $db);

if ($genere!="")
  {
  $queryspecie = "SELECT genere, specie FROM genspecie WHERE genere LIKE '{$genere}' ORDER BY specie";
  $resultspecie = mysql_query($queryspecie, $db);
  }

if ($genere!="" AND $specie!="")
  {
  $query_divordclafam = "SELECT divisione, ordine, classe, famiglia FROM archivio WHERE genere LIKE '{$genere}' AND specie LIKE '{$specie}'";
  $result_divordclafam = mysql_query($query_divordclafam, $db);
  while ($row = mysql_fetch_array($result_divordclafam)) 
    {
      $divisione=$row[divisione];
      $ordine=$row[ordine];
      $classe=$row[classe];
      $famiglia=$row[famiglia];
    }
  }
 
$querytossi = "SELECT tossi, post FROM tossicologia ORDER BY tossi";
$resulttossi = mysql_query($querytossi, $db);

$queryedita = "SELECT id, autore, scheda, micro, ca, ordine, famiglia, topic, tossi, datains, classe, divisione FROM archivio WHERE genere LIKE '{$genere}' AND specie LIKE '{$specie}'";
$resultedita = mysql_query($queryedita, $db);

?>

<table class="Table_Corpo" width="980" cellpadding="10" height="351">
    <tr class="testo1" height="327">
		    <td valign="top" bgcolor="#e6e6fa" width="954" height="327">
				    <div align="center">
						        <table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">
								        <tbody>
									      <tr>
										        <td width="940">
											             <table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
												           <tbody>
													             <tr class="testo1" height="50">
														              <td bgcolor="#FFFFFF" width="894" height="50">
															               <div align="center">
																                <b>Modifica Scheda</b>
																                <br />
															               </div>
																				  </td>
													             </tr>
												            </tbody>
											              </table>
											     </td>
									     </tr>
								       </tbody>
							     </table>
							     <br />
							     <br />
<form method="get" action="edit.php">
                   <table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
                      <tr>
                          <td></td>
                      </tr>
                      <tr class="testo1">
                          <td align="right" width="350">
                              Genere:&nbsp;&nbsp;
                              <select name="genere">
                    <?
                    if ($genere=="")
                      {
                      while ($row = mysql_fetch_array($result))
                        {
                        if ($row[genere]!=$inserito)
                          {
                    ?>
                                  <option value="<? echo "$row[genere]"?>"><? echo "$row[genere]"?></option>
                    <?
                          $inserito=$row[genere];
                          }
                        }
                      }
                    else
                      {
                    ?>
                                  <option value="<? echo "$genere"?>"><? echo "$genere"?></option>
                    <?
                      }
                    ?>
                              </select>
                          </td>
                          <td width="100" align="center">
                              <input src="../images/ok.png" type="image">
                          </td>
</form>

<form name="genspecie" method="get" action="edit.php">
                          <td width="350" align="left">
                              Specie:&nbsp;&nbsp;
                              <select name="specie">
                          <?
                          switch ($genere)
                            {
                            case "":
                          ?>
                                  <option value=""></option>
                          <?
                            break;
                            default:
                            if ($specie=="")
                              {
                              while ($row = mysql_fetch_array($resultspecie))
                          	   {
                          ?>
                          	      <option value="<? echo "$row[specie]"?>"><? echo "$row[specie]"?></option>
                          <?
                          	   }
                              }
                            else 
                              {
                          ?>
                                  <option value="<? echo "$specie"?>"><? echo "$specie"?></option>
                          <?
                              }
                            break;
                            }
                          ?>
                              </select>
                          </td>
                      </tr>
                      <tr>
                          <td></td>
                      </tr>
                   </table>
                   <table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
                        <tr>
                            <td width="400">
                              <input type="image" src="../images/delete.png" />
                            </td>
                            <td width="400" align="right">
                              <input onclick="form.genere.value='<? echo "$genere" ?>'" type="image" src="images/blocca.png" />
                            </td>
                        </tr>
                   </table>
                   <input name="genere" type="hidden"/>
                   <input name="edita" type="hidden" value="si" />
</form>

<?
switch ($edita)
  {
  case "si":
  while ($row = mysql_fetch_array($resultedita))
    {
    if ($verifica=="")
      {
      $id=$row[id];
?>
<form method="get" action="edit.php">
                   <table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
                      <tr>
                          <td></td>
                      </tr>
                      <tr class="testo1">
                          <td align="right" width="100">Autore:&nbsp;&nbsp;</td>
                          <td width="300" align="left">
                              <input type="text" size="30" name="autore" value="<? echo "$row[autore]"?>"/>
                          </td>
                          <td class="testo1" align="left" width="400">
                          Scheda:&nbsp;&nbsp;  
                              <select name="scheda">
                                                          <option <? if ($row[scheda]=="A") { ?> selected="selected" <? } ?>
                              value="A">Scheda AMINT</option>
                                                          <option <? if ($row[scheda]=="B") { ?> selected="selected" <? } ?>
                              value="B">Scheda Breve</option>
                                                          <option <? if ($row[scheda]=="S") { ?> selected="selected" <? } ?>
                              value="S">Scheda Sinonimo</option>
                             </select>
                          </td>
                      </tr>
                      <tr class="testo1">
                          <td align="right" width="100">Topic:&nbsp;&nbsp;</td>
                          <td width="300" align="left">
                            <input type="text" size="10" name="topic" value="<? echo "$row[topic]"; ?>"/>
                          </td>   
                          <?
                          if ($verifica==""){
                          $giorno=substr($row[datains], 6, 2);
                          $mese=substr($row[datains], 4, 2);
                          $anno=substr($row[datains], 0, 4);
                          }
                          ?>
                          <td align="left" width="400">Data:&nbsp;&nbsp;
                            <select name="giorno">
                                    <option <? if ($giorno=="01") { ?> selected="selected" <? } ?>
                                value="01">01</option>
                                    <option <? if ($giorno=="02") { ?> selected="selected" <? } ?>
                                value="02">02</option>
                                <option <? if ($giorno=="03") { ?> selected="selected" <? } ?>
                                value="03">03</option>
                                <option <? if ($giorno=="04") { ?> selected="selected" <? } ?>
                                value="04">04</option>
                                <option <? if ($giorno=="05") { ?> selected="selected" <? } ?>
                                value="05">05</option>
                                <option <? if ($giorno=="06") { ?> selected="selected" <? } ?>
                                value="06">06</option>
                                <option <? if ($giorno=="07") { ?> selected="selected" <? } ?>
                                value="07">07</option>
                                <option <? if ($giorno=="08") { ?> selected="selected" <? } ?>
                                value="08">08</option>
                                <option <? if ($giorno=="09") { ?> selected="selected" <? } ?>
                                value="09">09</option>
                                <option <? if ($giorno=="10") { ?> selected="selected" <? } ?>
                                value="10">10</option>
                                <option <? if ($giorno=="11") { ?> selected="selected" <? } ?>
                                value="11">11</option>
                                <option <? if ($giorno=="12") { ?> selected="selected" <? } ?>
                                value="12">12</option>
                                <option <? if ($giorno=="13") { ?> selected="selected" <? } ?>
                                value="13">13</option>
                                    <option <? if ($giorno=="14") { ?> selected="selected" <? } ?>
                                value="14">14</option>
                                <option <? if ($giorno=="15") { ?> selected="selected" <? } ?>
                                value="15">15</option>
                                <option <? if ($giorno=="16") { ?> selected="selected" <? } ?>
                                value="16">16</option>
                                <option <? if ($giorno=="17") { ?> selected="selected" <? } ?>
                                value="17">17</option>
                                <option <? if ($giorno=="18") { ?> selected="selected" <? } ?>
                                value="18">18</option>
                                <option <? if ($giorno=="19") { ?> selected="selected" <? } ?>
                                value="19">19</option>
                                <option <? if ($giorno=="20") { ?> selected="selected" <? } ?>
                                value="20">20</option>
                                <option <? if ($giorno=="21") { ?> selected="selected" <? } ?>
                                value="21">21</option>
                                <option <? if ($giorno=="22") { ?> selected="selected" <? } ?>
                                value="22">22</option>
                                <option <? if ($giorno=="23") { ?> selected="selected" <? } ?>
                                value="23">23</option>
                                <option <? if ($giorno=="24") { ?> selected="selected" <? } ?>
                                value="24">24</option>
                                <option <? if ($giorno=="25") { ?> selected="selected" <? } ?>
                                value="25">25</option>
                                <option <? if ($giorno=="26") { ?> selected="selected" <? } ?>
                                value="26">26</option>
                                <option <? if ($giorno=="27") { ?> selected="selected" <? } ?>
                                value="27">27</option>
                                <option <? if ($giorno=="28") { ?> selected="selected" <? } ?>
                                value="28">28</option>
                                <option <? if ($giorno=="29") { ?> selected="selected" <? } ?>
                                value="29">29</option>
                                <option <? if ($giorno=="30") { ?> selected="selected" <? } ?>
                                value="30">30</option>
                                <option <? if ($giorno=="31") { ?> selected="selected" <? } ?>
                                value="31">31</option>
                              </select> 
                            <select name="mese">
                                    <option <? if ($mese=="01") { ?> selected="selected" <? } ?>
                                value="01">01</option>
                                    <option <? if ($mese=="02") { ?> selected="selected" <? } ?>
                                value="02">02</option>
                                <option <? if ($mese=="03") { ?> selected="selected" <? } ?>
                                value="03">03</option>
                                <option <? if ($mese=="04") { ?> selected="selected" <? } ?>
                                value="04">04</option>
                                <option <? if ($mese=="05") { ?> selected="selected" <? } ?>
                                value="05">05</option>
                                <option <? if ($mese=="06") { ?> selected="selected" <? } ?>
                                value="06">06</option>
                                <option <? if ($mese=="07") { ?> selected="selected" <? } ?>
                                value="07">07</option>
                                <option <? if ($mese=="08") { ?> selected="selected" <? } ?>
                                value="08">08</option>
                                <option <? if ($mese=="09") { ?> selected="selected" <? } ?>
                                value="09">09</option>
                                <option <? if ($mese=="10") { ?> selected="selected" <? } ?>
                                value="10">10</option>
                                <option <? if ($mese=="11") { ?> selected="selected" <? } ?>
                                value="11">11</option>
                                <option <? if ($mese=="12") { ?> selected="selected" <? } ?>
                                value="12">12</option>                             
                               </select>
                             <select name="anno">
                                <option <? if ($anno=="2007") { ?> selected="selected" <? } ?>
                                value="2007">2007</option>
                                    <option <? if ($anno=="2008") { ?> selected="selected" <? } ?>
                                value="2008">2008</option>
                                <option <? if ($anno=="2009") { ?> selected="selected" <? } ?>
                                value="2009">2009</option>      
                                    <option <? if ($anno=="2010") { ?> selected="selected" <? } ?>
                                value="2010">2010</option>
                                    <option <? if ($anno=="2011") { ?> selected="selected" <? } ?>
                                value="2011">2011</option>           
                               </select>
                          (gg-mm-aaaa)
                          </td> 
                      </tr>
                   </table>
                   
                   <table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
                      <tr>
                          <td width="400"></td>
                          <td width="400" align="right"></td>
                      </tr>
                   </table>
                   
                   <? 
                      if ($row[scheda]=="S")
                        {$tipo_scheda=0;}
                      else
                        {$tipo_scheda=1;}
                      if ($tipo_scheda==1)
                      {
                   ?>
                   <table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
                      <tr>
                          <td></td>
                          <td></td>
                      </tr>
                      <tr class="testo1">
                          <td align="right" width="350">
                              Divisione:&nbsp;&nbsp;
                              <b><? if ($divisione!="") echo "$divisione"; else echo " n/d "; ?></b>
                          </td>
                          <td align="left" width="350">
                              Classe:&nbsp;&nbsp;
                              <b><? if ($classe!="") echo "$classe"; else echo " n/d "; ?></b>
                          </td>                    
                      </tr>
                      <tr class="testo1">
                          <td align="right" width="350">
                              Ordine:&nbsp;&nbsp;
                              <b><? if ($ordine!="") echo "$ordine"; else echo " n/d "; ?></b>
                          </td>                             
                          <td align="left" width="350">
                              Famiglia:&nbsp;&nbsp;
                              <b><? if ($famiglia!="") echo "$famiglia"; else echo " n/d "; ?></b>                            
                          </td>                       
                      </tr>
                      <tr>
                          <td></td>
                      </tr>
                   </table>
          <table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
          <tr>
          <td width="400">
          </td>
          <td width="400" align="right">
          </td>
          </tr>
          </table>    
          
          <table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
          <tr><td></td><td></td></tr>
          <tr>
          <td class="testo1" align="right" width="200">Commestibilit&agrave;:&nbsp;&nbsp;
          </td>
          <td class="testo1" align="left" width="300"><select name="comme">
                                        <option <? if ($row[ca]=="") { ?> selected="selected" <? } ?>
                                         value=""></option>
                                                                    <option <? if ($row[ca]=="C") { ?> selected="selected" <? } ?>
                                         value="C">Commestibile</option>
                                                                    <option <? if ($row[ca]=="C1") { ?> selected="selected" <? } ?>
                                        value="C1">Com. Condizionata</option>
                                                                    <option <? if ($row[ca]=="N") { ?> selected="selected" <? } ?>
                                        value="N">Non Commestibile</option>
                                          <option <? if ($row[ca]=="V") { ?> selected="selected" <? } ?>
                                        value="V">Velenoso</option>
                                        <option <? if ($row[ca]=="M") { ?> selected="selected" <? } ?>
                                        value="M">Mortale</option>
                                                                    </select>
          </td>
          <td class="testo1" align="right" width="100">Tossicologia:&nbsp;&nbsp;
          </td>
          <td class="testo1" align="left" width="300"><select name="tossi" style="width:200px">
          <?
          while ($tos = mysql_fetch_array($resulttossi)){
          ?>
          <option value="<? echo "$tos[tossi]"?>"
          <? if ($tos[tossi]==$row[tossi]) echo "selected"?>
          >
          <? echo "$tos[tossi]"?></option>
          <?
          }
          ?>
          </select>
          </td>
          </tr>
          <tr><td></td><td></td></tr>
          <tr>
          <td class="testo1" align="right" width="200">Micro:&nbsp;&nbsp;</td>
          <td class="testo1" align="left" width="300">
          <? if ($row[micro]=="0") { ?>
          <input type="checkbox" name="micro" />
          <?
          }
          else { ?>
          <input type="checkbox" checked="checked" value="1" name="micro" />
          <? } ?>            
          </td>
          <td class="testo1" align="right" width="100"></td>
          <td class="testo1" align="left" width="200"></td>
          </tr>
          <tr>
              <td></td>
              <td></td>
          </tr>
          </table>
          <br />
          <br />
          <?
       }
    }
   break;
    }
   }
   if ($verifica==""){ ?>
<table class="Table_Check" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Genere</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Specie</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Autore</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Divisione</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Classe</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Ordine</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Famiglia</div></td>
</tr>
<tr height="26">
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
</tr>
</table>
<br />
<table class="Table_Check" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Topic</div></td>
<td class="testo2" bgcolor="#427cae" width="260" height="26"><div align="center">Tossicologia</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Scheda</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Commestibilit&agrave;</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Micro</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Data</div></td>
</tr>
<tr height="26">
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="260"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
<td bgcolor="#dadde4" width="130"><div align="left"></div></td>
</tr>
</table>
<br /><br />
<table class="Table_Verifica" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400" align="center">Dati non verificati</td>
<td width="400" align="right"><input name="verifica" type="submit" value="Verifica Dati" /></td>
</tr>
</table>
<input name="genere" type="hidden" value="<? echo "$genere"; ?>" />
<input name="specie" type="hidden" value="<? echo "$specie"; ?>" />
<input name="edita" type="hidden" value="<? echo "$edita"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
</form>
<? }
else { 
if ($scheda=='S')
  {
      $divisione='';
      $classe='';
      $ordine='';
      $famiglia='';
      $tossi='';
      $comme='';
      $micro='';
  }
?>
  
<form method="post" action="aggiorna.php">
<table class="Table_Check" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Genere</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Specie</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Autore</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Divisione</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Classe</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Ordine</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Famiglia</div></td>
</tr>
<tr height="26">
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$genere" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$specie" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$autore" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$divisione" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$classe" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$ordine" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$famiglia" ?></div></td>
</tr>
</table>
<br />
<table class="Table_Check" width="910" border="1" cellspacing="2" cellpadding="4">
<tr height="26">
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Topic</div></td>
<td class="testo2" bgcolor="#427cae" width="260" height="26"><div align="center">Tossicologia</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Scheda</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Commestibilit&agrave;</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Micro</div></td>
<td class="testo2" bgcolor="#427cae" width="130" height="26"><div align="center">Data</div></td>
</tr>
<tr height="26">
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$topic" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="260"><div align="left"><? echo "$tossi" ?></div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left">
<?
switch ($scheda){
case 'B':
?>
Scheda Breve
<?
break;
case 'A':
?>
Scheda AMINT
<?
break;
case 'S':
?>
Scheda Sinonimo
<?
break;
}
?>
</div></td>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left">
<?
switch ($comme){
case 'C':
?>
Commestibile
<?
break;
case 'N':
?>
Non Commestibile
<?
break;
case 'V':
?>
Velenoso
<?
break;
case 'C1':
?>
Commestibilita' Condizionata
<?
break;
case 'M':
?>
Mortale
<?
break;
}
?>
</div></td>
<? switch ($micro){
case 'on':
?>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="center">X</div></td>
<?
break;
default:
?>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"></div></td>
<?
}
?>
<td class="testo0" bgcolor="#dadde4" width="130"><div align="left"><? echo "$giorno / $mese / $anno"; ?></div></td>
</tr>
</table>
<br /><br />
<table class="Table_Verificati" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400" align="center">Dati verificati</td>
<td width="400" align="right"><input name="submit" type="submit" value="Aggiorna Dati" /></td>
</tr>
</table>
<input name="genere" type="hidden" value="<? echo "$genere"; ?>" />
<input name="specie" type="hidden" value="<? echo "$specie"; ?>" />
<input name="divisione" type="hidden" value="<? echo "$divisione"; ?>" />
<input name="classe" type="hidden" value="<? echo "$classe"; ?>" />
<input name="ordine" type="hidden" value="<? echo "$ordine"; ?>" />
<input name="famiglia" type="hidden" value="<? echo "$famiglia"; ?>" />
<input name="topic" type="hidden" value="<? echo "$topic"; ?>" />
<input name="tossi" type="hidden" value="<? echo "$tossi"; ?>" />
<input name="scheda" type="hidden" value="<? echo "$scheda"; ?>" />
<input name="comme" type="hidden" value="<? echo "$comme"; ?>" />
<input name="micro" type="hidden" value="<? echo "$micro"; ?>" />
<input name="giorno" type="hidden" value="<? echo "$giorno"; ?>" />
<input name="mese" type="hidden" value="<? echo "$mese"; ?>" />
<input name="anno" type="hidden" value="<? echo "$anno"; ?>" />
<input name="autore" type="hidden" value="<? echo "$autore"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
</form>
<? } ?>

<br /><br />

					  </div></td>
</table>

<?
// chiusura pagina
foot();
?>
