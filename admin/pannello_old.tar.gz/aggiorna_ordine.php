<?
$id=$_REQUEST['id'];
$ordine=$_REQUEST['ordine'];
$archivio=$_REQUEST['archivio'];
$ordine_old=$_REQUEST['ordine_old'];

include("top_foot.inc.php");
include("../config.inc.php");
top();

?>
<table Class="Table_coda" width="980" bgcolor="#D3D3D3" height="20">

				<tr>

					<td bgcolor="#B0C4DE">
					
							<table  border="0" cellspacing="2" cellpadding="0" height="30">

								<tr>

									<td  align="center" bgcolor="#B0C4DE" width="200" height="30">

											<a class="link10" href="index.php">PANNELLO AMMINISTRAZIONE</a></div>

									</td>

									<td align="center" bgcolor="#B0C4DE" width="200" height="30">


									</td>

								</tr>

							</table>

					</td>

				</tr>

			</table>

<?
  $db = mysql_connect($db_host, $db_user, $db_password);
  if ($db == FALSE)
    die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  mysql_select_db($db_name, $db)
    or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");
	

$query = "UPDATE ordine SET ordine='$ordine' WHERE id='$id'";

$query_archivio = "UPDATE archivio SET ordine='$ordine' WHERE ordine='$ordine_old'";

if (mysql_query($query, $db))
	   	$stampa1='Modifica Ordine avvenuta con successo. Riga' . $id;
else
		$stampa1='Errore aggiornamento dati!!!';		

switch ($archivio){
	
	case "1":
	if (mysql_query($query_archivio, $db))
	   	$stampa2='Modifica tabella Archivio avvenuta con successo.';
	else
		$stampa2='Errore aggiornamento tabella Archivio!!!';
	
	break;
}

?>
			
<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

				  <td valign="top" bgcolor="#e6e6fa" width="954" height="327">

					  <div align="center">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

 												<tbody>

 													<tr class="testo1" height="50">

 														<td bgcolor="#e6e6fa" width="894" height="50">

 															<div align="center">

 																<b><? echo "$stampa1";?></b><br>
																<b><? echo "$stampa2";?></b><br>
 															</div>														</td>
 													</tr>
 												</tbody>
											</table>
                                            <p>&nbsp;</p>
                  </table>


<?
	//endif;
	  mysql_close($db);
// chiude la verifica della presenza dei dati
foot();
?>
