<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
top_admin();
link_admin();

$genere=($_GET['genere']!="")? $_GET['genere'] :"";
$specie=($_GET['specie']!="")? $_GET['specie'] :"";
$edita=($_GET['edita']!="")? $_GET['edita'] :"";
$cancella=($_GET['cancella']!="")? $_GET['cancella'] :"";
$id=($_GET['id']!="")? $_GET['id'] :"";

$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");


$query = "SELECT genere, specie FROM genspecie ORDER BY genere";
$result = mysql_query($query, $db);

if ($genere!=""){
$queryspecie = "SELECT genere, specie FROM genspecie WHERE genere LIKE '{$genere}' ORDER BY specie";
$resultspecie = mysql_query($queryspecie, $db);
}

$queryedita = "SELECT id, autore, scheda, micro, ca, ordine, famiglia, topic, tossi, datains, classe, divisione FROM archivio WHERE genere LIKE '{$genere}' AND specie LIKE '{$specie}'";
$resultedita = mysql_query($queryedita, $db);
?>

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">


					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Elimina Scheda</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table>										</td>
									</tr>
								</tbody>
							</table>

					          <p>&nbsp;</p>
<form method="get" action="delete.php">
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td>
</td>
</tr>
<tr class="testo1">
<td align="right" width="350">
Genere:&nbsp;&nbsp;<select name="genere">
<?
if ($genere==""){
while ($row = mysql_fetch_array($result))
{
if ($row[genere]!=$inserito){
?>
<option value="<? echo "$row[genere]"?>"><? echo "$row[genere]"?></option>
<?
$inserito=$row[genere];
}
}
}
else {
?>
<option value="<? echo "$genere"?>"><? echo "$genere"?></option>
<?
}
?>
</select>
</td>
<td width="100" align="center">
<input src="../images/ok.png" type="image">
</form>


<form name="genspecie" method="get" action="delete.php">
</td>
<td width="350" align="left">
specie:&nbsp;&nbsp;<select name="specie">
<?
switch ($genere){
case "":
?>
<option value=""></option>
<?
break;
default:
if ($specie==""){
while ($row = mysql_fetch_array($resultspecie))
	{
	?>
	<option value="<? echo "$row[specie]"?>"><? echo "$row[specie]"?></option>
	<?
	}
}
else {
?>
<option value="<? echo "$specie"?>"><? echo "$specie"?></option>
<?
}
break;
}
?>
</select>
</td>
</tr>
<tr><td></td></tr>
</table>
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
<input type="image" src="../images/delete.png">
</td>
<td width="400" align="right">
<input onclick="form.genere.value='<? echo "$genere" ?>'" type="image" src="images/blocca.png">
</td>
</tr>
</table>
<input name="genere" type="hidden"/>
<input name="edita" type="hidden" value="si" />
</form>

<?
switch ($edita){
case "si":
while ($row = mysql_fetch_array($resultedita))
{
$id=$row[id];
?>
<table class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Id:&nbsp;&nbsp;<b><? echo "$id";?></b>
</td>
</tr>
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Autore:&nbsp;&nbsp;<b><? echo "$row[autore]";?></b>
</td>
</tr>
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Divisione:&nbsp;&nbsp;<b><? echo "$row[divisione]";?></b>
</td>
<td align="left">
Classe:&nbsp;&nbsp;<b><? echo "$row[classe]";?></b>
</td>
</tr>
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Ordine:&nbsp;&nbsp;<b><? echo "$row[ordine]";?></b>
</td>
<td align="left">
Famiglia:&nbsp;&nbsp;<b><? echo "$row[famiglia]";?></b>
</td>
</tr>
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Topic:&nbsp;&nbsp;<b><? echo "$row[topic]";?></b>
</td>
<td align="left">
Tossicologia:&nbsp;&nbsp;<b><? echo "$row[tossi]";?></b>
</td>
</tr>
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Scheda:&nbsp;&nbsp;<b><? echo "$row[scheda]";?></b>
</td>
<td align="left">
Commestibilita':&nbsp;&nbsp;<b><? echo "$row[ca]";?></b>
</td>
</tr>
<tr><td></td></tr>
<tr class="testo1">
<td align="left">
Micro:&nbsp;&nbsp;<b><?
if (($row[micro])=="0") echo "";
else {
echo "X";
}
?></b>
</td>
<td align="left">
Data:&nbsp;&nbsp;<b><?
if (($row[datains])=="0") echo "";
else {
$giorno=substr($row[datains], 6, 2);
$mese=substr($row[datains], 4, 2);
$anno=substr($row[datains], 0, 4);
echo "$giorno/$mese/$anno";
}
?>
</b>
</td>
</tr>
<tr><td></td></tr>
</table>
<table width="800" border="0" cellspacing="1" cellpadding="4" height="46">
<tr>
<td width="400">
</td>
<td width="400" align="right">
</td>
</tr>
</table>
<br /><br />
<?
if ($cancella==""){
?>
<form name="elimina" method="get" action="delete.php">
<table class="Table_Verifica" border="0" cellspacing="1" cellpadding="4" height="46">
<tr class="testo1">
<td width="400" align="center">Procedi con eliminazione scheda?</td>
<td width="400" align="right"><input name="cancella" type="submit" value="Elimina" /></td>
</tr>
</table>
<input name="genere" type="hidden" value="<? echo "$genere"; ?>" />
<input name="specie" type="hidden" value="<? echo "$specie"; ?>" />
<input name="edita" type="hidden" value="<? echo "$edita"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
</form>
<?
}
else {
?>
<form method="post" action="delete_id.php">
<table class="Table_Verificati" border="0" cellspacing="1" cellpadding="4" height="46">
<tr class="testo1">
<td width="400" align="center">Confermi?</td>
<td width="400" align="right"><input name="conferma" type="submit" value="Si" /></td>
</tr>
</table>
<input name="genere" type="hidden" value="<? echo "$genere"; ?>" />
<input name="specie" type="hidden" value="<? echo "$specie"; ?>" />
<input name="edita" type="hidden" value="<? echo "$edita"; ?>" />
<input name="id" type="hidden" value="<? echo "$id"; ?>" />
</form>
<?
	}
}
}
 ?>
<br /><br />

                                </p>
					          <p>&nbsp;</p>
					  </div></td>
</table>

<?
// chiusura pagina
foot();
?>
