<?
$id=$_REQUEST['id'];
$genere=$_REQUEST['genere'];
$specie=$_REQUEST['specie'];
$archivio=$_REQUEST['archivio'];
$divordclafam=$_REQUEST['divordclafam'];
$gen_old=$_REQUEST['gen_old'];
$spe_old=$_REQUEST['spe_old'];

include("top_foot.inc.php");
include("../config.inc.php");
top_admin();
link_admin();

  $db = mysql_connect($db_host, $db_user, $db_password);
  if ($db == FALSE)
    die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");

  mysql_select_db($db_name, $db)
    or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");
	

$query = "UPDATE genspecie SET genere='$genere', specie='$specie' WHERE id='$id'";

$query_archivio = "UPDATE archivio SET genere='$genere', specie='$specie' WHERE (genere='$gen_old' AND specie='$spe_old')";

$query_divordclafam = "UPDATE gendivordclafam SET genere='$genere' WHERE genere='$gen_old'";

if (mysql_query($query, $db))
	   	$stampa1='Modifica Genere-Specie avvenuta con successo. Riga' . $id;
else
		$stampa1='Errore aggiornamento dati!!!';		

switch ($archivio){
	
	case "1":
	if (mysql_query($query_archivio, $db))
	   	$stampa2='Modifica tabella Archivio avvenuta con successo.';
	else
		$stampa2='Errore aggiornamento tabella Archivio!!!';
	
	break;
}

switch ($divordclafam){
  
  case "1":
  if (mysql_query($query_divordclafam, $db))
      $stampa3='Modifica tabella [Divisione-Ordine-Classe-Famiglia] avvenuta con successo.';
  else
    $stampa3='Errore aggiornamento tabella [Divisione-Ordine-Classe-Famiglia]!!!';
  
  break;
}

?>
			
<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

				  <td valign="top" bgcolor="#e6e6fa" width="954" height="327">

					  <div align="center">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

 												<tbody>

 													<tr class="testo1" height="50">

 														<td bgcolor="#e6e6fa" width="894" height="50">

 															<div align="center">

 																<b><? echo "$stampa1";?></b><br>
																<b><? echo "$stampa2";?></b><br>
																<b><? echo "$stampa3";?></b><br>
 															</div>														</td>
 													</tr>
 												</tbody>
											</table>
                                            <p>&nbsp;</p>
                  </table>


<?
	//endif;
	  mysql_close($db);
// chiude la verifica della presenza dei dati
foot();
?>
