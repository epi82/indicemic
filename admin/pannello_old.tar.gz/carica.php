<?
include ("../config.inc.php");
include ("top_foot.inc.php");

//intestazione
top_admin();
link_admin();

$carica=($_GET['carica']!="")? $_GET['carica'] :"";
$db = mysql_connect($db_host, $db_user, $db_password);

if ($db == FALSE)
	die ("Errore nella connessione. Verificare i parametri nel file config.inc.php");
mysql_select_db($db_name, $db)
  or die ("Errore nella selezione del database. Verificare i parametri nel file config.inc.php");
  
$query = "SELECT genere FROM genspecie GROUP By genere ORDER By genere";
$result = mysql_query($query, $db);
  
?>

<form method="post" action="save_carica.php">
<? 
switch ($carica){
case "genspecie":
?>

    <table class="Table_Corpo" width="980" cellpadding="10" height="351">
        <tr class="testo1" height="327">
    		    <td valign="top" bgcolor="#e6e6fa" width="954" height="327">
    				    <div align="center">
    						        <table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">
    								        <tbody>
    									         <tr>
    										          <td width="940">
    											               <table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
    												                <tbody>
    													                 <tr class="testo1" height="50">
    														                  <td bgcolor="#e6e6fa" width="894" height="50">
    															                   <div align="center">
    																                    <b>Inserimento Nuovo Genere-specie</b>
    																                    <br/>
    															                   </div>								
    															                </td>
    													                 </tr>
    												                </tbody>
    											               </table>
    											        </td>
    									        </tr>
    								        </tbody>
    							      </table>
                        <br />
                        <br />
                        <table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
                            <tr height="25">
                        		    <td></td>
                        	  </tr>
                        	  <tr>
                            		<td align="right" width="100" class="testo1">Genere:&nbsp;&nbsp;</td>
                            		<td align="left" width="640"><input type="text" id="gen_id" size="100" name="genere"/></td>
                            		<td align="right" width="100"></td>
                        	  </tr>
                        	  <tr>
                            		<td align="right" width="100" class="testo1">specie:&nbsp;&nbsp;</td>
                            		<td align="left" width="640"><input type="text" size="100" name="specie"/></td>
                            		<td align="right" width="100"></td>
                        	  </tr>
                        	  <tr height="25">
                        		    <td></td>
                        	  </tr>
                            <input name="carica" type="hidden" value="genspecie" />
<?
break;
case "divordclafam":
?>
    <table class="Table_Corpo" width="980" cellpadding="10" height="351">
            <tr class="testo1" height="327">
                <td valign="top" bgcolor="#e6e6fa" width="954" height="327">
                    <div align="center">
                            <table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">
                                <tbody>
                                   <tr>
                                      <td width="940">
                                             <table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
                                                <tbody>
                                                   <tr class="testo1" height="50">
                                                      <td bgcolor="#e6e6fa" width="894" height="50">
                                                         <div align="center">
                                                            <b>Inserimento nuova relazione Divisione-Classe-Ordine-Famiglia</b>
                                                            <br/>
                                                         </div>               
                                                      </td>
                                                   </tr>
                                                </tbody>
                                             </table>
                                      </td>
                                  </tr>
                                </tbody>
                            </table>
                            <br />
                            <br />
                            <table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
                              <tr height="25">
                                  <td></td>
                              </tr>
                              <tr>
                                  <td align="right" width="100" class="testo1">Genere:&nbsp;&nbsp;</td>
                                  <td align="left" width="640">
                                      <select name="genere">
                                      <?
                                      while ($row = mysql_fetch_array($result))
                                        {                                                          
                                      ?>
                                          <option value="<? echo "$row[genere]"?>"><? echo "$row[genere]"?></option>
                                      <?                                                                  
                                        }                          
                                      ?> 
                                      </select>
                                  </td>
                                  <td align="right" width="100"></td>                       
                              </tr>
                              <tr>
                                  <td align="right" width="100" class="testo1">Divisione:&nbsp;&nbsp;</td>
                                  <td align="left" width="640"><input type="text" id="div_id" size="100" name="divisione"/></td>
                                  <td align="right" width="100"></td>
                              </tr>
                              <tr>
                                  <td align="right" width="100" class="testo1">Classe:&nbsp;&nbsp;</td>
                                  <td align="left" width="640"><input type="text" id="cla_id" size="100" name="classe"/></td>
                                  <td align="right" width="100"></td>
                              </tr>                              
                              <tr>
                                  <td align="right" width="100" class="testo1">Ordine:&nbsp;&nbsp;</td>
                                  <td align="left" width="640"><input type="text" id="ord_id" size="100" name="ordine"/></td>
                                  <td align="right" width="100"></td>
                              </tr>
                              <tr>
                                  <td align="right" width="100" class="testo1">Famiglia:&nbsp;&nbsp;</td>
                                  <td align="left" width="640"><input type="text" id="fam_id" size="100" name="famiglia"/></td>
                                  <td align="right" width="100"></td>
                              </tr>        
                              <input name="carica" type="hidden" value="divordclafam" />
<!--
<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">
					

					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Inserimento Nuova Divisione</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table></td>
									</tr>
								</tbody>
							</table>
		
<table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
	<tr height="25">
		<td>
		</td>
	</tr>
	<tr>
		<td align="right" width="100" class="testo1">Divisione:&nbsp;&nbsp;</td>
		<td align="left" width="640"><input type="text" size="100" name="div"/></td>
		<td align="right" width="100"></td>
	</tr>
	<tr height="25">
		<td>
		</td>
	</tr>
<input name="carica" type="hidden" value="div" />

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">
					

					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Inserimento Nuova Classe</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table></td>
									</tr>
								</tbody>
							</table>
		

<table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
	<tr height="25">
		<td>
		</td>
	</tr>
	<tr>
		<td align="right" width="100" class="testo1">Classe:&nbsp;&nbsp;</td>
		<td align="left" width="640"><input type="text" size="100" name="classe"/></td>
		<td align="right" width="100"></td>
	</tr>
	<tr height="25">
		<td>
		</td>
	</tr>
<input name="carica" type="hidden" value="classe" />

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">
					

					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Inserimento Nuovo Ordine</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table></td>
									</tr>
								</tbody>
							</table>
		

<table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
	<tr height="25">
		<td>
		</td>
	</tr>
	<tr>
		<td align="right" width="100" class="testo1">Ordine:&nbsp;&nbsp;</td>
		<td align="left" width="640"><input type="text" size="100" name="ordine"/></td>
		<td align="right" width="100"></td>
	</tr>
	<tr height="25">
		<td>
		</td>
	</tr>
<input name="carica" type="hidden" value="ordine" />

<table class="Table_Corpo" width="980" cellpadding="10" height="351">

				<tr class="testo1" height="327">

					<td valign="top" bgcolor="#e6e6fa" width="954" height="327">
					

					  <div align="center">

							<table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">

								<tbody>

									<tr>

										<td width="940">

											<table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">

												<tbody>

													<tr class="testo1" height="50">

														<td bgcolor="#e6e6fa" width="894" height="50">

															<div align="center">

																<b>Inserimento Nuova Famiglia</b><br>
															</div>														</td>
													</tr>
												</tbody>
											</table></td>
									</tr>
								</tbody>
							</table>
		

<table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
	<tr height="25">
		<td>
		</td>
	</tr>
	<tr>
		<td align="right" width="100" class="testo1">Famiglia:&nbsp;&nbsp;</td>
		<td align="left" width="640"><input type="text" size="100" name="fami"/></td>
		<td align="right" width="100"></td>
	</tr>
	<tr height="25">
		<td>
		</td>
	</tr>
<input name="carica" type="hidden" value="fami" />
-->
<?
break;
case "tossi":
?>

    <table class="Table_Corpo" width="980" cellpadding="10" height="351">
		    <tr class="testo1" height="327">
				    <td valign="top" bgcolor="#e6e6fa" width="954" height="327">	
					     <div align="center">
							         <table width="940" border="0" cellspacing="0" cellpadding="1" bgcolor="#7694c8" height="46">
								          <tbody>
									           <tr>
										            <td width="940">
											                 <table width="940" border="0" cellspacing="0" cellpadding="3" align="center" height="50">
												                  <tbody>
													                   <tr class="testo1" height="50">
														                    <td bgcolor="#e6e6fa" width="894" height="50">
															                     <div align="center">
															 	                       <b>Inserimento Nuovo Link Tossicologia</b>
															 	                       <br />
															                     </div>														
															                  </td>
													                   </tr>
												                  </tbody>
											                 </table>
											          </td>
									           </tr>
								         </tbody>
							         </table>		

                       <br />
                       <br />
                       <table  width="840" class="Table_Insert" border="0" cellspacing="1" cellpadding="4" height="46">
                      	<tr height="25">
                      		<td>
                      		</td>
                      	</tr>
                      	<tr>
                      		<td align="right" width="100" class="testo1">Tossicologia:&nbsp;&nbsp;</td>
                      		<td align="left" width="640"><input type="text" size="100" name="tossi"/></td>
                      		<td align="right" width="100"></td>
                      	</tr>
                      	<tr>
                      		<td align="right" width="100" class="testo1">Post:&nbsp;&nbsp;</td>
                      		<td align="left" width="640"><input type="text" size="100" name="post"/></td>
                      		<td align="right" width="100"></td>
                      	</tr>
                      	<tr height="25">
                      		<td>
                      		</td>
                      	</tr>
                       <input name="carica" type="hidden" value="tossi" />
<?
break;
}
?>
                      	<tr>
                      		<td align="center" width="100"></td>
                      		<td align="right" width="640"><input name="submit" type="submit" value="Inserisci Dati" /></td>
                      		<td align="right" width="100"></td>
                      	</tr>
					             </table>
					     </div>
					  </td>
        </tr>
    </table>
</form>

<?
// chiusura pagina
foot();
?>
